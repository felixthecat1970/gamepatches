--Lua configs by felixthecat1970
--ゴジラ怪獣大乱闘 〜地球最終決戦〜 
--Godzilla - Kaijuu Dairantou - Chikyuu Saishuu Kessen (Japan) [SLPM-65805] (Version 1.03) crc=7EB64263
--sha1=5a87459c6770331278c39da09cf5d8793ca3bf99 clean dump hash http://redump.org/disc/47817/
--!!REQUIRED CLEAN DUMP MATCH SHA1 EQUAL OR PATCH WILL NOT WORK!!

apiRequest(2.0)

local emuObj = getEmuObject()

--v2 corrected code structure, code correction, unlock multilanguag, enable native progressive scan, port widescreen video mode 16:9 created by ElHecht \ Arapapa
--Set language change (?) number by desired lang
-- 0 - japanese
-- 1 - english
-- 2 - french
-- 3 - spanish
-- 4 - german
-- 5 - italian
emuObj.SetPs2Lang(1) -- <-edit number to your desired language

--A code block for unlock multilanguage + english audio with multilanguague subtitles
--disable B "emuMediaPatch" 4 lines below with " -- " before use this

--emuMediaPatch(0x,1CD0F9 12 + 0x3E8, { 0xAC850070}, { 0x00000000 })
--emuMediaPatch(0x,1CD28A 12 + 0x2A4, { 0x2C42003B}, { 0x2C42003D })

--B code block for unlock multilanguage + japanese audio (Undub), languages subtitles will not show
--disable A "emuMediaPatch" 2 above lines with " -- " above before use this 

emuMediaPatch(0x,1CD289 12 + 0x210, { 0x03E00008}, { 0xAC850080 })
emuMediaPatch(0x,1CD289 12 + 0x218, { 0x00000000}, { 0x03E00008 })
emuMediaPatch(0x,1CD361 12 + 0x15C, { 0x00000000}, { 0x3C1B005E })
emuMediaPatch(0x,1CD361 12 + 0x1E4, { 0x00000000}, { 0x83707350 })

--add native progressive scan mode + widescreen native code ported
emuMediaPatch(0x,1CD260 12 + 0x430, { 0x34038026}, { 0x34030066 })
emuMediaPatch(0x,1CD253 12 + 0x20, { 0x10400005}, { 0x00000000 })
emuMediaPatch(0x,1CD260 12 + 0x568, { 0x24030003}, { 0x24030001 })
emuMediaPatch(0x,1CD260 12 + 0x558, { 0x640D0800}, { 0x00000000 })
emuMediaPatch(0x,1CD25E 12 + 0x424, { 0x24A50001}, { 0x0000282D })
emuMediaPatch(0x,1CD261 12 + 0x68, { 0x24A50023}, { 0x24A50033 })
emuMediaPatch(0x,1CD261 12 + 0x64, { 0x64C900E8}, { 0x64C90140 })
emuMediaPatch(0x,1CD25E 12 + 0x468, { 0x2484FFFF}, { 0x00000000 })
emuMediaPatch(0x,1CD28E 12 + 0x6CC, { 0xE6000124}, { 0x08054684 })
emuMediaPatch(0x,1CD28E 12 + 0x6D0, { 0xE6010128}, { 0x00000000 })
emuMediaPatch(0x,1CD0AA 12 + 0x310, { 0x00000000}, { 0x3C013F40 })
emuMediaPatch(0x,1CD0AA 12 + 0x314, { 0x00000000}, { 0x4481F000 })
emuMediaPatch(0x,1CD0AA 12 + 0x318, { 0x00000000}, { 0x461E0002 })
emuMediaPatch(0x,1CD0AA 12 + 0x31C, { 0x00000000}, { 0xE6000124 })
emuMediaPatch(0x,1CD0AA 12 + 0x320, { 0x00000000}, { 0xE6010128 })
emuMediaPatch(0x,1CD0AA 12 + 0x324, { 0x00000000}, { 0x08090F75 })











