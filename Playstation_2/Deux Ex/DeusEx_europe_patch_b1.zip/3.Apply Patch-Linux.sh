#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir old
chmod +x xdelta3
./xdelta3 -v -d -s "Deus Ex (Europe).iso" "vcdiff/Deus Ex (Europe).iso.vcdiff" "Deus_Ex_patched.iso"
mv "Deus Ex (Europe).iso" old
