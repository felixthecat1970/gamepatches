#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Silent Hill 4 - The Room (Japan) (En,Ja).iso"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Silent Hill 4 - The Room (Japan) (En,Ja).iso" "vcdiff/Silent Hill 4 - The Room (Japan) (En,Ja).iso.vcdiff" "./output/Silent Hill 4 - The Room (Japan) (En,Ja)-patchedCONSOLE.iso"
