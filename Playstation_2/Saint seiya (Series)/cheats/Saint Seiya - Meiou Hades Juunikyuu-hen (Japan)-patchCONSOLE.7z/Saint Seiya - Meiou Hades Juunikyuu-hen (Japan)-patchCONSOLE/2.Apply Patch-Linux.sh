#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Saint Seiya - Meiou Hades Juunikyuu-hen (Japan).iso"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Saint Seiya - Meiou Hades Juunikyuu-hen (Japan).iso" "vcdiff/Saint Seiya - Meiou Hades Juunikyuu-hen (Japan).iso.vcdiff" "./output/Saint Seiya - Meiou Hades Juunikyuu-hen (Japan) - patchCONSOLE.iso"
