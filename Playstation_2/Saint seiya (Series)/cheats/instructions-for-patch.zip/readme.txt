v1
Disclaimer codes are not guarantee work perfect use under your responsibility.

Saint seiya series on ps2 only released in japan and europe with their respective problems (japan only japanese for non japanese) and europe (only in blurry PAL 50hz/25fps tv mode) so debugging executables couple moths ago i find the games has locked their video modes and languages, with this codes you can play European version in NTSC 60hz tv mode and framerate unlocked ( 60fps) but for people has the japanese version you can play in 4 languages, the languages files are hidden (or maybe unfinished) this codes unlock the languages and convert your japanese copy in multilanguage game with japanese intro and music, like always use my tutorials in my blog o check readme.

+All in NTSC 60hz Video mode
+All with 60 fps unlock
+optional codes for Hades changed the framebufer config for less blurry image in emulators (disable or not use it if you have problems on original hardware or consoles)

Saint Seiya - The Sanctuary (Europe) (En,Ja,Fr,De,Es,It) sha1:919baf4e53ed2838181d1ee9de88be9ef51ee8e7
file: SLES-53201_BE2213F9.pnach

Saint Seiya - Sanctuary Juunikyuu-hen (Japan) sha1:f7009062d4a685a4adbd313fc7f79e1ad058652a
file: SLPS-25476_7970F63C.pnach

Saint Seiya - The Hades (Europe) (En,Ja,Fr,Es,It) sha1:6da748b0a966a884fc08b3d0d56ffb1bf51848c7
file: SLES-54162_531AB6BC.pnach

Saint Seiya - Meiou Hades Juunikyuu-hen (Japan) sha1:fdd7b2169f2bb687778d358a53609664f92694fd
file: SLPS-25744_9051D2DF.pnach

For hades series:
+ Optional Convert (Japan) version hades to multilanguage (enabled by default)
+ Optional Convert (Europe) version to japanese (intro still play genereic song from europe region)

Games tested with PCSX2 QT 64 emulator and hades series with PS3 BC-ps2 hardware compactible model.

PS2 Progressive scan custom code list online
 8 minute read
Playstation 2 custom codes list wich enable progressive scan TV mode for NTSC / PAL for consoles and emulators.

How to apply patches.

1 - dump your game into .ISO (google is your friend)

2 - Compare the sha1 hash for verify correct .ISO dump

3 - APPLY/PATCH DIRECTLY GAME DUMPS .ISO=DVD FOR PS2/PS3/PS4/PC
use PS2 Patch Engine PC tool by pelvicthrustman 1.03 (search psxplace.com for tool)

open ps2_patch_engine tool in pc (windows only)
look in table/sheet or open with notepad app the xxxx.pnach file for the game according your game version / region
load the xxxxx.iso or xxxxxx.bin game dump in ps2_patch_engine tool and select “PNACH” option
copy all or desired “patch=XXXXXX..etc” code lines and paste in ps2_patch_engine (white window) and press “PATCH”
if you do all correctly the app will generate a “ your-game-xxxxxx_pached.iso or .bin file, use this file for load in your console PS2 or build (PS3,PS4) !!! This will change your game dump CRC keep in mind if you use patched dumps and other cheats (crc name will not match in this scenario need to be changed)!!!

optional:withow modify the game dump with PCSX2 Qt 64 emulator copy the xxxxx.pnach files to cheats folder enable in options.