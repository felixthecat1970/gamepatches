#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Metal Gear Solid 2 - Sons of Liberty - Trial Edition (USA) (Demo).bin"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Metal Gear Solid 2 - Sons of Liberty - Trial Edition (USA) (Demo).bin" "vcdiff/Metal Gear Solid 2 - Sons of Liberty - Trial Edition (USA) (Demo).bin.vcdiff" "./output/Metal Gear Solid 2 - Sons of Liberty - Trial Edition (USA) (Demo)-patched.iso"
