#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir ./output
chmod +x ./exec/xdelta3_x64_linux
echo Place the files to be patched in the \"original\" directory with the following names:
echo --------------------
echo "Devil May Cry 3 - Dante's Awakening (Europe) (En,Fr,De,Es,It) (Special Edition).iso"
echo --------------------
echo Patched files will be in the \"output\" directory
read -p "Press enter to continue..." inp
./exec/xdelta3_x64_linux -v -d -s "./original/Devil May Cry 3 - Dante's Awakening (Europe) (En,Fr,De,Es,It) (Special Edition).iso" "vcdiff/Devil May Cry 3 - Dante's Awakening (Europe) (En,Fr,De,Es,It) (Special Edition).iso.vcdiff" "./output/Devil May Cry 3 - (Europe) (Special Edition)-patch.iso"
